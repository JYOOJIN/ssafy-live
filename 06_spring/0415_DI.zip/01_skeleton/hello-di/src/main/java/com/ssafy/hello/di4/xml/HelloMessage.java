package com.ssafy.hello.di4.xml;

public interface HelloMessage {

	String hello(String name);
	
}
