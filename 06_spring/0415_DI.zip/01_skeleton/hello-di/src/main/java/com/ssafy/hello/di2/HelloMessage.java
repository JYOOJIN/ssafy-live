package com.ssafy.hello.di2;

public interface HelloMessage {

	String hello(String name);
	
}
