package com.ssafy.hello.di5.annotation;

public interface HelloMessage {

	String hello(String name);
	
}
