package com.ssafy.hello.di3;

public class HelloMessageKor implements HelloMessage {

	public String hello(String name) {
		return "안녕하세요 " + name;
	}
	
}
