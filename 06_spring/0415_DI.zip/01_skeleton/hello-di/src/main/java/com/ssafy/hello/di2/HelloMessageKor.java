package com.ssafy.hello.di2;

public class HelloMessageKor implements HelloMessage {

	public String hello(String name) {
		return "안녕하세요 " + name;
	}
	
}
