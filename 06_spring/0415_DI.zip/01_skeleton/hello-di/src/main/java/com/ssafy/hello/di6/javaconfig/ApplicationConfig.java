package com.ssafy.hello.di6.javaconfig;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


public class ApplicationConfig {

}
