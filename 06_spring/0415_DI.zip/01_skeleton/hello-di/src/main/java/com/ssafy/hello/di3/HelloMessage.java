package com.ssafy.hello.di3;

public interface HelloMessage {

	String hello(String name);
	
}
