import java.util.HashMap;

class UserSolution {
    final int MAX_N = 10000;
    final int MAX_M = 10;

    static class Node{
        HashMap<Integer, Node> map;
        Integer id;

        Node(){
            map = new HashMap<>();
            id = null;
        }
    }

    static int size;

    static Node root;

    void init(int N, int M, char mImageList[][][])
    {
        root = new Node();
        size = M;

        for(int i = 0; i < N; ++i){
            Node cur = root;
            for(int p = 0; p < size; ++p){
                int data = 0;
                for(int q = 0; q < size; ++q){
                    data = (data << 1) | ((mImageList[i][p][q] & 1) == 0 ? 0 : 1);
                }

                if(!cur.map.containsKey(data)){
                    cur.map.put(data, new Node());
                }


                cur = cur.map.get(data);

                if(p == size - 1){
                    if(cur.id == null){
                        cur.id = i;
                    }
                }
            }
        }
    }
    int findImage(char mImage[][])
    {
        int[] datas = new int[size];
        for(int i = 0; i < size; ++i){
            int data = 0;
            for(int j = 0; j < size; ++j){
                data = (data << 1) | ((mImage[i][j] & 1) == 0 ? 0 : 1);
            }
            datas[i] = data;
        }

        return recur(0, root, datas, 0)[1] + 1;
    }

    int[] recur(int depth, Node node, int[] dat, int fails){
        if(depth == size){
            return new int[]{fails, node.id};
        }

        int[] result = new int[]{-1, -1};

        for(int comp : node.map.keySet()){
            int diff = Integer.bitCount((comp ^ dat[depth]));

            if(diff + fails < 3){
                int[] ret = recur(depth + 1, node.map.get(comp), dat, fails + diff);

                if(ret == null)
                    continue;

                if(result[0] == -1)
                    result = ret;
                else{
                    if(result[0] == ret[0]){
                        result[1] = Math.min(result[1], ret[1]);
                    }else if(result[0] > ret[0]){
                        result = ret;
                    }
                }
            }
        }

        if(result[0] == -1)
            return null;

        return result;
    }
}
