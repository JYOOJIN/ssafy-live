import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

class UserSolution {

    static class Place implements Comparable<Place>{
        int x;
        int y;
        int id;
        boolean disabled;

        Place(int id, int x, int y){
            this.id = id;
            this.x = x;
            this.y = y;
            disabled = false;
        }

        @Override
        public int compareTo(Place o) {
            int rst = Integer.compare(this.x, o.x);
            if(rst != 0)
                return rst;
            return Integer.compare(this.y, o.y);
        }
    }

    static HashMap<Integer, Place> places = null;
    static HashMap<Integer, int[]> defected = null;

    static HashMap<Integer, ArrayList<Place>> dir04; // 상하 y
    static HashMap<Integer, ArrayList<Place>> dir15; // 우상좌하 대각  x + y -> 같음
    static HashMap<Integer, ArrayList<Place>> dir26; // 좌우 x
    static HashMap<Integer, ArrayList<Place>> dir37; // 좌상우하 대각 x - y -> 같음

    static HashMap<Integer, ArrayList<Place>>[] dirs = null;
    static final int[][] deltas = {
            {-1, 0}, {-1, 1}, {0, 1}, {1, 1}, {1, 0}, {1, -1}, {0, -1}, {-1, -1}
    };

    void init() {
        places = new HashMap<>(30000, 0.5f);
        defected  = new HashMap<>(5000, 0.5f);

        dir04 = new HashMap<>();
        dir15 = new HashMap<>();
        dir26 = new HashMap<>();
        dir37 = new HashMap<>();
        dirs = new HashMap[]{dir04, dir15, dir26, dir37};
    }

    void addPlace(int pID, int r, int c) {
        Place place = new Place(pID, r, c);
        places.put(pID, place);

        /*
    dir04; // 상하 y
    dir15; // 우상좌하 대각  x + y -> 같음
    dir26; // 좌우 x
    dir37; // 좌상우하 대각 x - y -> 같음
         */
        ArrayList<Place> list[] = new ArrayList[4]; //new ArrayList[]{dir04.get(c), dir15.get(r +c), dir26.get(r), dir37.get(r - c)};

        if(!dir04.containsKey(c)){
            ArrayList<Place> tmp = new ArrayList<>(11);
            dir04.put(c, tmp);
            list[0] = tmp;
        }else{
            list[0] = dir04.get(c);
        }

        if(!dir15.containsKey(r + c)){
            ArrayList<Place> tmp = new ArrayList<>(11);
            dir15.put(r + c, tmp);
            list[1] = tmp;
        }else{
            list[1] = dir15.get(r + c);
        }

        if(!dir26.containsKey(r)){
            ArrayList<Place> tmp = new ArrayList<>(11);
            dir26.put(r, tmp);
            list[2] = tmp;
        }else{
            list[2] = dir26.get(r);
        }

        if(!dir37.containsKey(r - c)){
            ArrayList<Place> tmp = new ArrayList<>(11);
            dir37.put(r - c, tmp);
            list[3] = tmp;
        }else{
            list[3] = dir37.get(r - c);
        }

        for(ArrayList lst : list){
            int idx = Collections.binarySearch(lst, place);
            lst.add(-(idx + 1), place);
        }
    }

    void removePlace(int pID) {
        Place place = places.remove(pID);

        ArrayList<Place> list[] = new ArrayList[]{dir04.get(place.y), dir15.get(place.x + place.y), dir26.get(place.x), dir37.get(place.x - place.y)};
        for(ArrayList lst : list){
            int idx = Collections.binarySearch(lst, place);
            lst.remove(idx);
        }
    }

    void contactTracing(int uID, int visitNum, int moveInfo[], int visitList[]) {
        Place place = places.get(moveInfo[0]);
        visitList[0] = moveInfo[0];
        visit(visitNum, place, 1, moveInfo, visitList);
        defected.put(uID, Arrays.copyOf(visitList, visitNum));

        for(int i = 0; i < visitNum; ++i){
            places.get(visitList[i]).disabled = true;
        }
    }

    void visit(int visitNum, Place place, int cur, int moveInfo[], int visitList[]){
        if(cur >= visitNum)
            return;

                /*
    dir04; // 상하 y
    dir15; // 우상좌하 대각  x + y -> 같음
    dir26; // 좌우 x
    dir37; // 좌상우하 대각 x - y -> 같음
         */

        boolean prev = false; // 0 1 6 7 -> 이전 방향
        HashMap<Integer, ArrayList<Place>> dir;
        int key = 0;
        switch (moveInfo[cur]){
            case 0:
                prev = true;
                case 4:
                dir = dir04;
                key = place.y;
                break;

            case 1:
                prev = true;
                case 5:
                dir = dir15;
                key = place.x + place.y;
                break;

            case 6:
                prev = true;
                case 2:
                dir = dir26;
                key = place.x;
                break;

            case 7:
                prev = true;
                case 3:
                dir = dir37;
                key = place.x - place.y;
                break;

            default:
                dir = new HashMap<>();
        }

        ArrayList<Place> lst = dir.get(key);

        int idx = Collections.binarySearch(lst, place);

        Place next;

        do{
            if(prev){
                next = lst.get(--idx);
            }else{
                next = lst.get(++idx);
            }
        } while(next.disabled);

        visitList[cur] = next.id;
        visit(visitNum, next, cur + 1, moveInfo, visitList);
    }

    void disinfectPlaces(int uID) {
        int[] lst = defected.get(uID);
        for(int idx : lst){
            if(places.containsKey(idx)){
                places.get(idx).disabled = false;
            }
        }
    }
}