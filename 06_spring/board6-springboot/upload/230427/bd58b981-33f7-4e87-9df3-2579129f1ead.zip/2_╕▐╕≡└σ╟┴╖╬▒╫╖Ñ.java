import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

class UserSolution
{
    static int Height, Width;
    static List<Character> list = null;
    static ListIterator<Character> iter = null;
    static int[] cnt;

    static int[] global_cnt;

    void init(int H, int W, char mStr[])
    {
        Height = H;
        Width = W;
        cnt = new int[26];
        list = new ArrayList<>(H * W + 1);
        global_cnt =  new int[26];

        for(int i = 0; i < mStr.length; ++i){
            if(mStr[i] == '\0')
                break;

            list.add(mStr[i]);
            ++cnt[mStr[i] - 'a'];
            ++global_cnt[mStr[i] - 'a'];
        }
        iter = list.listIterator(0);
    }

    void insert(char mChar)
    {
        iter.add(mChar);
        ++global_cnt[mChar - 'a'];
    }

    char moveCursor(int mRow, int mCol)
    {
        int idx = iter.nextIndex();
        int nIdx = (mRow - 1) * Width + (mCol - 1);

        if(nIdx == 0){
            cnt = Arrays.copyOf(global_cnt, 26);
            iter = list.listIterator(0);
            if(list.size() == 0)
                return '$';
            return list.get(0);
        }

        int diff = (nIdx - idx);

        if(diff == 0){
            if(!iter.hasNext())
                return '$';
            char rst = iter.next();
            iter.previous();
            return rst;
        }

        char rst = '$';
        if(diff < 0){
            if(-diff > list.size() / 2){
                iter = list.listIterator(0);
                cnt = Arrays.copyOf(global_cnt, 26);

                while(nIdx-- >= 0){
                    rst = iter.next();
                    --cnt[rst - 'a'];
                }
                char tmp = iter.previous();
                ++cnt[rst - 'a'];
            }else{
                while(diff++ < 0){
                    rst = iter.previous();
                    ++cnt[rst - 'a'];
                }
            }
        }else if(nIdx >= list.size()){
            cnt = new int[26];
            iter = list.listIterator(list.size());
            return '$';
        }else{
            if(diff > list.size() / 2){
                cnt = new int[26];
                iter = list.listIterator(list.size());

                diff = (list.size() - nIdx);
                while(diff-- > 0){
                    rst = iter.previous();
                    ++cnt[rst - 'a'];
                }
            }else{
                while(diff-- >= 0){
                    rst = iter.next();
                    --cnt[rst - 'a'];
                }
                char tmp =iter.previous();
                ++cnt[tmp - 'a'];
            }
        }

        return rst;
    }

    int countCharacter(char mChar)
    {
        return cnt[mChar - 'a'];
    }
}