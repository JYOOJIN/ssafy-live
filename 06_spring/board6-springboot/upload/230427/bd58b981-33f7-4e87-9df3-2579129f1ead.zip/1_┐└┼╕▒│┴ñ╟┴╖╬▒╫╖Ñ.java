import java.util.*;

class UserSolution {
    static HashMap<String, LinkedList<String>> corrections;
    static HashMap<String, HashSet<Integer>> queryTimes;

    static class User{
        int id;
        LinkedList<Query> queries;
        User(int id){
            this.id = id;
            queries = new LinkedList<>();
        }

        void search(int time, String word){
            Iterator<Query> iter = queries.listIterator(0);
            while(iter.hasNext()){
                Query query = iter.next();
                if(time - query.time > 10)
                    break;

                if(query.word.equals(word))
                    continue;

                String key = query.word + "/" + word;

                HashSet<Integer> set = null;
                if(!queryTimes.containsKey(key)){
                    set = new HashSet<>();
                    queryTimes.put(key, set);
                }else{
                    set = queryTimes.get(key);
                }

                if(set.size() >= 3 || set.contains(this.id))
                    continue;

                if(correctable(word, query.word)){
                    set.add(this.id);

                    if(set.size() >= 3){
                        if(corrections.containsKey(query.word)){
                            corrections.get(query.word).add(word);
                        }else{
                            LinkedList<String> lst = new LinkedList<>();
                            lst.add(word);
                            corrections.put(query.word, lst);
                        }
                    }
                }
            }

            queries.addFirst(new Query(time, word));
        }

        boolean correctable(String str, String str2){
            if(Math.abs(str.length() - str2.length()) > 1){
                return false;
            }

            if(str.length() == str2.length()){
                boolean charFlip = false;
                for(int i = 0; i < str.length(); ++i){
                    if(str.charAt(i) != str.charAt(i)){
                       if(!charFlip)
                           charFlip = true;
                       else return false;
                    }
                }
                return !charFlip;
            }else if(str.length() > str2.length()){
                String tmp = str;
                str = str2;
                str2 = tmp;
            }


            /*
            StringBuilder sb = new StringBuilder();

            boolean charFlip = false;
            for(int i = 0; i < str.length(); ++i){
                if(!charFlip){
                    if(str.charAt(i) != str2.charAt(i)){
                        charFlip = true;
                    }else{
                        sb.append(str.charAt(i));
                    }
                }else{
                    sb.append(str2.charAt(i));
                }
            }
            if(!charFlip)
                sb.append(str2.charAt(str2.length() - 1));

            return str.equals(sb.toString());
             */

            boolean charFlip = false;
            for(int i = 0; i < str.length(); ++i){
                if(str.charAt(i - (charFlip ? 1 : 0)) != str2.charAt(i)){
                    if(!charFlip)
                        charFlip = true;
                    else return false;
                }
            }

            if(str.charAt(str.length() - 1) != str2.charAt(str2.length() - 1)){
                if(charFlip)
                    return false;
                return true;
            }

            return true;

        }
    }

    static class Query{
        int time;
        String word;

        Query(int time, String word){
            this.time = time;
            this.word = word;
        }
    }

    static int numUser;
    static HashMap<Integer, User> userMap;

    void init(int n) {
        corrections = new HashMap<>();
        queryTimes = new HashMap<>();
        numUser = n;
        userMap = new HashMap<>(2 * numUser, 0.5f);
    }

    int search(int mId, int searchTimestamp, char[] searchWord, char[][] correctWord) {
        User user = null;
        if(userMap.containsKey(mId)){
            user = userMap.get(mId);
        }else{
            user = new User(mId);
            userMap.put(mId, user);
        }

        StringBuilder sb = new StringBuilder();
        for(int i = 0; searchWord[i] != '\0'; ++i){
            sb.append((char)(searchWord[i] & ((1 << 7) - 1)));
        }
        String word = sb.toString();

        user.search(searchTimestamp, word);

        if(corrections.containsKey(word)){
            LinkedList<String> lst = corrections.get(word);
            ListIterator<String> iter = lst.listIterator(0);

            for(int i = 0; i < lst.size(); ++i){
                String rst = iter.next();
                int idx = 0;
                while(idx < rst.length()){
                    correctWord[i][idx] = rst.charAt(idx);
                    ++idx;
                }
                correctWord[i][idx] = '\0';
            }

            return lst.size();
        }else{
            correctWord[0][0] = '\0';
        }

        return 0;
    }
}
