package com.ssafy.book.model.service;

public interface BookService {

}
