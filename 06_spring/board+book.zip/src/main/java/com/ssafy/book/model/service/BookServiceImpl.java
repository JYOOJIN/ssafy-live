package com.ssafy.book.model.service;

public class BookServiceImpl {

}
