package com.ssafy.good;

import org.springframework.stereotype.Service;

@Service
public class GoodService {
	public String getMsg() {
		return "Good service 입니다";
	}
}
