package com.ssafy.hello.service;

import org.springframework.stereotype.Service;

@Service
public class HelloService {
	
	public String getMsg() {
		return "Hello Service 입니다";
		
	}
	
}
